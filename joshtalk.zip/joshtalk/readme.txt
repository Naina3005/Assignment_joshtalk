Task Management API

This is a backend API built using Django and Django REST Framework (DRF). It allows users to create tasks, assign them to users, and retrieve assigned tasks.

Features:
- Create a new task with a name and description.
- Assign a task to one or multiple users.
- Retrieve all tasks assigned to a specific user.

Technology Stack:
- Backend: Django, Django REST Framework (DRF)
- Database: SQLite (default, can be changed)
- API Format: JSON (RESTful API)

API Endpoints:
1. Create a Task (POST /api/create-task/)
2. Assign Task to Users (POST /api/assign-task/{task_id}/)
3. Get Tasks for a Specific User (GET /api/user-tasks/{user_id}/)

How it Works:
1. A user creates a task by sending task details to the API.
2. The task is stored in the database.
3. The task can be assigned to one or multiple users.
4. Users can retrieve tasks assigned to them.

Setup Instructions:
1. Install dependencies using pip.
2. Run database migrations.
3. Start the Django server.
4. Test API endpoints using Postman or cURL.

This API is designed to be simple and efficient for managing tasks in a system.
