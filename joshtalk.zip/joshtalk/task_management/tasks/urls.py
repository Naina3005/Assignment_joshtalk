from django.urls import path
from .views import CreateTaskView, assign_task, UserTasksView

urlpatterns = [
    path('create-task/', CreateTaskView.as_view(), name='create-task'),
    path('assign-task/<int:task_id>/', assign_task, name='assign-task'),
    path('user-tasks/<int:user_id>/', UserTasksView.as_view(), name='user-tasks'),
]
