from rest_framework import generics
from django.contrib.auth.models import User
from .models import Task
from .serializers import TaskSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view


class CreateTaskView(generics.CreateAPIView):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer


@api_view(['POST'])
def assign_task(request, task_id):
    try:
        task = Task.objects.get(id=task_id)
        user_ids = request.data.get('user_ids', [])
        users = User.objects.filter(id__in=user_ids)
        task.assigned_users.set(users)
        return Response({"message": "Task assigned successfully."})
    except Task.DoesNotExist:
        return Response({"error": "Task not found."}, status=404)


class UserTasksView(generics.ListAPIView):
    serializer_class = TaskSerializer

    def get_queryset(self):
        user_id = self.kwargs['user_id']
        return Task.objects.filter(assigned_users__id=user_id)

